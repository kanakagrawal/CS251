Team Name-Alpha

Honor Code:
Kanak Agrawal- I,pledge to my honor that I had not given or recieved any unauthorised assistance in this or any previous assignment.

Yash Wagh- I,pledge to my honor that I had not given or recieved any unauthorised assistance in this or any previous assignment.

Ajay Yadav- I,pledge to my honor that I had not given or recieved any unauthorised assistance in this or any previous assignment.


Kanak Agrawal(150050016)- 100%
Yash Wagh(150050023)- 90%
Ajay Yadav(150050056)- 90%

We have attempt the second bonus question and corrected 2 more forms.

Reflection Essay:
	Task A : First we started learning bootstrap, but after a day decided not to use bootstrap and make our own css file with many classes defined. With this we could know many many attributes and use them. Also the three of us didn't do the first task together,i.e, our pages have different CSS wrapper. We exploited basic CSS as much as we can.
	TASK B: Understanding XSS was tough but after understanding it was pretty easy.