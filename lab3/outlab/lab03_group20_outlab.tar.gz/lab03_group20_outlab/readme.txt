Group Number : 20
Group Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honour Code :
	I, Kanak Agrawal, pledge to my honour that I have not given or taken any unauthorized assisstance in this or any previous assignment.
	I, Yash Wagh, pledge to my honour that I have not given or taken any unauthorized assisstance in this or any previous assignment.
	I, Ajay Yadav, pledge to my honour that I have not given or taken any unauthorized assisstance in this or any previous assignment.

Contribution :
	Kanak : 100%
	Yash : 0%
	Ajay : 100%

Citations:
	for taskC in concatenating all files together ( cat $(ls) )
		-http://unix.stackexchange.com/questions/223300/single-line-command-to-cat-last-file-in-ls-lrt-output

Reflection Essay:
	We learned how to read documentation of commands. We were amazed on seeing the lab questions and found it very interesting.