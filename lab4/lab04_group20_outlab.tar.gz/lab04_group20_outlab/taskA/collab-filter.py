import csv

class reviewer:
	def __init__(self,name):
		self.name = name
		self.watched_movies={}

	def give_rating(self,movie,rating):
		if(rating!=-1):
			self.watched_movies[movie]=rating

	def __str__(self):
		return self.name

	def distance(self,user):
		a = set(user.watched_movies.keys())
		b = set(self.watched_movies.keys())
		common_moviename = a&b
		distance = 0
		for movie in common_moviename:
			distance = distance + (self.watched_movies[movie]-user.watched_movies[movie])**2
		self.relation = 1/(1+distance)

	def __lt__(self, other):
         return self.relation < other.relation

reviewers_list = []							#List to store all reviewers
movies = {}									#Dictionary with key as movie name and value as list of reviewers who reviewed it
file = open("movie-ratings.csv")
reader = csv.reader(file)
data = list(reader)
for j in range(1,len(data[0])):
	movies[data[0][j]]=[]					#Initializing all dictionary values for all movies as empty list
for i in range(1,len(data)):
	reviewers_list.append(reviewer(data[i][0]))
	for j in range(1,len(data[i])):
		reviewers_list[i-1].give_rating(data[0][j],float(data[i][j]))
		movies[data[0][j]].append(reviewers_list[i-1])
file.close()
file = open("user_preference.csv")
reader = csv.reader(file)
data = list(reader)
user = reviewer("Kanak")
for i in range(len(data[0])):
	user.give_rating(data[0][i],float(data[1][i]))
for u in reviewers_list:
	u.distance(user)
reviewers_list.sort()						#It will sort the list such that reviewer_list[0] has minimum similarity with user
print("Reviewers with maximum euclidean based distance similarity in increasing order of similarity are:")
print(*reviewers_list,sep='\n')