import math

class Complexnumber():
	def __init__(self, realpart, imagpart):
		self.r = realpart
		self.i = imagpart
 
	def __add__(self, complex_2):
		return Complexnumber(complex_2.r+self.r,complex_2.i+self.i)

	def __sub__(self, complex_2):
		return Complexnumber(complex_2.r-self.r,complex_2.i-self.i)

	def __mul__(self, complex_2):
		return Complexnumber((complex_2.r*self.r)-(complex_2.i*self.i),(complex_2.i*self.r)+(complex_2.r*self.i))

	def __truediv__(self, complex_2):
		x=Complexnumber((complex_2.r*self.r)-(complex_2.i*self.i),(complex_2.i*self.r)+(complex_2.r*self.i))
		y=(complex_2.r**2) + (complex_2.i**2)
		return Complexnumber((x.r)*1.0/y , (x.i)*1.0/y)

	def __str__(self):
		return "(%s,%s)"%(self.r,self.i)

	def mysquare(self):
		return self*self

	def __repr__(self):
		return "(%s,%s)"%(self.r,self.i)

	def __invert__(self):
		return Complexnumber(self.r,-self.i)

	def __eq__(self, complex_2):
		return (self.r==complex_2.r and self.i==complex_2.i)
	
	def norm(self):
		return math.sqrt((self.i**2)+(self.r**2))	