from complexno import *

def myexponent(var):
	if(not isinstance(var,Complexnumber)):
		var = Complexnumber(var,0)
	res=Complexnumber(1.0,0)
	term=Complexnumber(1,0)
	for i in range(1,7):
		term = var*term
		term = term/Complexnumber(i,0)
		res=term+res
	return res