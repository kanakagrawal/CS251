Group 20

Team Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honor Code:
I, Kanak Agrawal, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Yash Wagh, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Ajay Yadav, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.

Percentage Contribution : 
Kanak   : 100%
Yash   : 50%
Ajay   : 60%

Citations:
	For random numbers : 
		http://www.cplusplus.com/reference/cstdlib/rand/
	problem in cross initialization inside switch : 
		http://stackoverflow.com/questions/2392655/what-are-the-signs-of-crosses-initialization
	Tutorial to understand how to use b2ContactListener for contact detection:
		http://www.iforce2d.net/b2dtut/collision-callbacks
	Box2D Manual:
		http://box2d.org/manual.pdf


Reflection Essay:
	Code Warrior!
	We certainly feel like one! It was a real fun working with so many files and to know how they were linked to one another. At start we one need to apply force to understand how files are interlinked but after a while it becomes so interesting and tempting. Box2D was a good experience. Looking forward to more such labs.