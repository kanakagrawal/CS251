Group 20

Team Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honor Code:
I, Kanak Agrawal, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Yash Wagh, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Ajay Yadav, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.

Percentage Contribution : 
Kanak   : 100%
Yash   : 100%
Ajay   : 100%

Citations:
	http://tex.stackexchange.com/questions/26334/how-to-concatenate-strings-to-e-g-create-commands-that-return-lists
	http://tex.stackexchange.com/questions/225919/how-to-split-input-string-in-a-latex-command
	http://tex.stackexchange.com/questions/11349/how-do-you-define-your-environment-such-as-to-use-for-some-parameters
	http://tex.stackexchange.com/questions/74353/what-commands-are-there-for-horizontal-spacing

Reflection Essay:
	From taskA0, we learnt how latex is a powerful tool and is present in many other softwares.
	Making Resume was not fun but boring. Still the way environment and commands are defined was new to learn. Also we could figure out that to do a certain task there were many different methods and all vary with each other slightly here and there. Sometimes there was no option but to use \vspace{} to adjust vertical height which restricted in learning the power of latex.For ex: \begin{itemize} leaves some vertical space so to uno that space leaving there must be some option to it but a jugaad way is to do \vspace{-2em}
	String parsing in latex was the toughest to figure out. And when i could it required a lot of effort to remove the first blank in a string(converting " part1" to "part1")
	Task A3 was easy(Didn't get time to do Ackermann)