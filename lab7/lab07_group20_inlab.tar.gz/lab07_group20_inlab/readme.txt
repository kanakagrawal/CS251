Group 20

Team Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honor Code:
I, Kanak Agrawal, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Yash Wagh, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Ajay Yadav, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.

Percentage Contribution : 
Kanak   : 100%
Yash   : 100%
Ajay   : 100%


We want to use a Lateday for the inlab07.

The reason is while doing outlab we recognized a mistake in our taskC.R code which would give a compilation error. It was not recognized during inlab because we were working on rstudio and before executing any new code we didn't do rm(list=ls()) due to which a variable 'x' not defined in taskC.R was used in it instead of 'x1' but there was no error as the rstudio environment had a variable 'x' in it.