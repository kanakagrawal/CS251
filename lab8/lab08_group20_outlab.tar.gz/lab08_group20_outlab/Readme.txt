Group 20

Team Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honor Code:
I, Kanak Agrawal, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Yash Wagh, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Ajay Yadav, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.

Percentage Contribution : 
Kanak   : 100%
Yash   : 100%
Ajay   : 100%


citations:
	http://unix.stackexchange.com/questions/10745/how-do-i-time-a-specific-command

Reflection Essay:

	This lab was easier than other labs but at the same time was very very useful. gprof and gdb can be very useful tools for us. Infact we used it in our DSA lab. Doxygen and pyplot were not that interesting. Also, the maker of lab has done quite a creative job and deserves applause.