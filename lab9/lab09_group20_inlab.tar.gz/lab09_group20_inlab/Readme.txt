Group 20

Team Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honor Code:
I, Kanak Agrawal, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Yash Wagh, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Ajay Yadav, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.

Percentage Contribution : 
Kanak   : 100%
Yash   : 100%
Ajay   : 100%


We had our Viva today. So, we have got some extra time. It should be considered while deciding the penalty of late submission.