Group 20

Team Members : (Kanak Agrawal,150050016),(Yash Wagh,150050023),(Ajay Yadav,150050056)

Honor Code:
I, Kanak Agrawal, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Yash Wagh, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.
I, Ajay Yadav, pledge to my honour that I have not given or used any unauthorized assisstance in this or any previous assignment.

Percentage Contribution : 
Kanak   : 100%
Yash   : 0%
Ajay   : 100%


We are using our 2 Latedays for this lab.


Reflection Essay:
	The concept of threading was new and good to learn. Also making a GUI was nice. taskA was easy and boring. Apart from that other tasks were nice. One thing good was that apart from java we learned different other concepts also in this lab.